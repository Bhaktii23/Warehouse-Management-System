package com.warehouseinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
